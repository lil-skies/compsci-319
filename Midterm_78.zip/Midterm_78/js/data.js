function appendData(data)
{
    let mainContainer;
    
    for(let element of data)
    {
        console.log(element["product-name"]);
        
        if(element["product-name"] == "Supreme Box Logo Crew")
        {
            mainContainer = document.getElementById("SBLC_json");
            mainContainer.innerHTML = `${element["product-name"]}`;
            
            mainContainer = document.getElementById("SBLCD_json");
            mainContainer.innerHTML = `${element["product-description"]}`;
            
            mainContainer = document.getElementById("SBLCP_json");
            mainContainer.innerHTML = `$${element["price"]}`;
            
        }
        
        if(element["product-name"] == "White Arcteryx Shell Coat")
        {
            mainContainer = document.getElementById("WASC_json");
            mainContainer.innerHTML = `${element["product-name"]}`;
            
            mainContainer = document.getElementById("WASCD_json");
            mainContainer.innerHTML = `${element["product-description"]}`;
            
            mainContainer = document.getElementById("WASCP_json");
            mainContainer.innerHTML = `$${element["price"]}`;
                
        }
        
        if(element["product-name"] == "Black Rick Owens Jacket")
        {
            mainContainer = document.getElementById("BROJ_json");
            mainContainer.innerHTML = `${element["product-name"]}`;
            
            mainContainer = document.getElementById("BROJD_json");
            mainContainer.innerHTML = `${element["product-description"]}`;
            
            mainContainer = document.getElementById("BROJP_json");
            mainContainer.innerHTML = `$${element["price"]}`;
                
        }
            
            
    }
    
    
}

function load_json()
{
    fetch("assets/js/data.json")
        .then (function(response) {return response.json();})
        .then (function(data) {appendData(data);})
        .catch(function(err) {console.log("Error: " + err);})
    
}




