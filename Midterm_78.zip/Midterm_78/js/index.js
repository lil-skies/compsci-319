let total_price = 0;

//item quantity
let Supreme_Box_Logo_Crew_Blue_quantity = 0;
let Arcteryx_Jackey_White_quantity = 0;
let Rick_Owens_Jacket_Black_quantity = 0;

function Add_Supreme_Box_Logo_Crew_Blue()
{
    total_price += 299;
    Supreme_Box_Logo_Crew_Blue_quantity += 1;
    alert("Added [Blue Supreme Box Logo Crew] to cart!");
    
}

function Add_Arteryx_Jacket_White()
{
    total_price += 230;
    Arcteryx_Jackey_White_quantity += 1;
    alert("Added [White Arteryx Shell Coat] to cart!");
    
}

function Add_Rick_Owens_Jacket_Black()
{
    total_price += 799;
    Rick_Owens_Jacket_Black_quantity += 1;
    alert("Added [Black Rick Owens Jacket] to cart!");
    
}

function Save_Cart()
{
    //price
    window.localStorage.setItem("total_price", total_price);
    
    //quantities
    window.localStorage.setItem("Supreme_Box_Logo_Crew_Blue_quantity", Supreme_Box_Logo_Crew_Blue_quantity)
    window.localStorage.setItem("Arcteryx_Jacket_White_quantity", Arcteryx_Jackey_White_quantity);
    window.localStorage.setItem("Rick_Owens_Jacket_Black_quantity", Rick_Owens_Jacket_Black_quantity);
        
}






